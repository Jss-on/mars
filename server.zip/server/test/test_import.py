import sys
sys.path.append('.')
from src import USBStorage, Audio, GPIO
